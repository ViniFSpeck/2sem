<html>
	<head>
		<title>Biblioteca Particular</title>
	</head>
	
	<body>
		<h1>Biblioteca Particular</h1>
		<p>Que safadinho você hein!!! Querendo entrar no site sem se logar!</p>
		<p>Clique <a href="index.php">aqui</a> para entrar. </p>
	</body>
</html>