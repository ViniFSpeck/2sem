<?php
	include "seguranca.php";
	include "conexao.php";
	
	$sql = "select * from livros";
	$resultado = mysqli_query($conexao, $sql);
	
	$listaLivros = array();
	while ($livro = mysqli_fetch_assoc($resultado)){
		$listaLivros[] = $livro;
	}
?>
<html>
	<head>
		<style>
			table{
				text-align:center;
			}
			td{
				padding:4px;
			}
		</style>
		<title>Biblioteca Particular</title>
	</head>
	
	<body>
		<h1>Biblioteca Particular</h1>
		<h2>Lista de Livros</h2>
		
		<a href="formLivro.php?acao=i">incluir livro</a><br>
		<table border=1  style="padding:1">
			<tr>
				<td>Codigo</td>
				<td>Titulo</td>
				<td>Autor</td>
				<td colspan=2>Opções</td>
			</tr>
			
			<?php foreach ($listaLivros as $livro) : ?>
			<tr>
				<td> <?php echo $livro['livCodigo']?> </td>
				<td> <?php echo $livro['livTitulo']?> </td>
				<td> <?php echo $livro['livAutor']?> </td>
				<td> <a href="formLivro.php?acao=a&cod=<?php echo $livro['livCodigo']?>">alterar</a> </td>
				<td> <a href="formLivro.php?acao=e&cod=<?php echo $livro['livCodigo']?>">excluir</a> </td>
			</tr>
			<?php endforeach; ?>
			
		</table>
	</body>
</html>