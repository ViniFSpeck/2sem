<?php
	include "seguranca.php";
	include "conexao.php";
	
	$sql = "select * from livros";
	$resultado = mysqli_query($conexao, $sql);
	
	$listaLivros = array();
	while ($livro = mysqli_fetch_assoc($resultado)){
		$listaLivros[] = $livro;
	}
?>
<html>
	<head>
		<style>
			table{
				text-align:center;
			}
			td{
				padding:4px;
			}
		</style>
		<title>Biblioteca Particular</title>
	</head>
	
	<body>
		<h1>Biblioteca Particular</h1>
		<h2>Lista de Livros</h2>
		<table border=1  style="padding:1">
			<tr>
				<td>Codigo</td>
				<td>Titulo</td>
				<td>Autor</td>
			</tr>
			
			<?php
				foreach ($listaLivros as $livro){
					echo "<tr>";
					echo "<td>";
					echo $livro['livCodigo'];
					echo "</td>";
					echo "<td>";
					echo $livro['livTitulo'];
					echo "</td>";
					echo "<td>";
					echo $livro['livAutor'];
					echo "</td>";
					echo "</tr>";
				}
			?>
			
		</table>
	</body>
</html>