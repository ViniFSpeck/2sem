<?php
	$acao=$_GET['acao'];
	$cod=$_GET['cod'];
?>
<html>
	<head>
		<title>Biblioteca Particular</title>
	</head>
	
	<body>
		<h1>Biblioteca Particular</h1>
		<h2>Livro:</h2>
		<p><?php
		$sel= "SELECT * from 'livros' WHERE"
			echo $acao;
			echo $cod;
		?></p>
	</body>
</html>