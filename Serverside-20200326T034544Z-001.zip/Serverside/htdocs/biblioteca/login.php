<html>
	<head>
		<title>Biblioteca Particular</title>
	</head>
	<body>
		<h1>Biblioteca Particular</h1>
		
		<form action="entrar.php" method="post">
		<table>
			<tr>
				<td><label for="fUsuario">Usuário</label></td>
				<td><input type="text" id="fUsuario" name="fUsuario"></td>
			</tr>
			<tr>
				<td><label for="fSenha">Senha</label></td>
				<td><input type="password" id="fSenha" name="fSenha"></td>
			</tr>
			<tr>
				<td><input type="submit" value="Entrar"></td>
				<td><input type="reset" value="Limpar"></td>
			</tr>
		</table>
	</body>
</html>