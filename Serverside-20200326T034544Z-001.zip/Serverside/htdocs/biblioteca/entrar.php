<?php
	session_start();
	$_SESSION['usuario'] = "";
	header("Location: login.php");
	include "conexao.php";
	
	$usu = $_POST['fUsuario'];	
	$senha = $_POST['fSenha'];
	
	$sql = "select * from usuarios where usuLogin='".$usu."'and usuSenha='".$senha."'"; //comando sql
	$resultado = mysqli_query($conexao, $sql); //funcao consulta executada na conexao com o comando sql alocado p resultado
	
	$qtdLinhas = mysqli_num_rows($resultado);
	if($qtdLinhas == 1)
	{
		$usuario = mysqli_fetch_array($resultado);
		$_SESSION['usuario'] = $usuario['usuLogin'];
		header("Location: lista.php");
	}
	else{
		header("Location: errologin.php");
	}

?>

