<?php
	$dbServidor = "127.0.0.1";
	$dbUsuario  = "root";
	$dbSenha    = "";
	$dbBanco    = "biblioteca";
	
	$conexao = mysqli_connect($dbServidor, $dbUsuario, $dbSenha, $dbBanco);
	
	if (mysqli_connect_errno($conexao))
	{
		echo "<h1>Erro ao conectar!</h1>";
		die();
	}
	
?>