<html>
	<head>
		<title>Biblioteca Particular</title>
	</head>
	
	<body>
		<h1>Biblioteca Particular</h1>
		<p>Usuário inexistente ou senha incorreta</p>
		<p>Clique <a href="index.php">aqui</a> para voltar</p>
	</body>
</html>