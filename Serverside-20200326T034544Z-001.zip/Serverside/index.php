<?php
	$bdServidor = '127.0.0.1';
	$bdUsuario = 'root';
	$bdSenha = '';
	$bdBanco = 'biblioteca';
	
	$conexao = mysqli_connect($bdServidor, $bdUsuario, $bdSenha, $bdBanco);
	
	if (mysqli_connect_errno($conexao))
	{
		echo 'Deu erro!';
	}
	else
	{
		echo 'Deu certo!';
		$listaLivros = buscarLivros($conexao);
	}
	
	
function buscarLivros($conexao)
{
	$sqlBusca = 'select * from livros';
	$resultado = mysqli_query($conexao, $sqlBusca);
	$todosLivros = array();
	
	while ($umLivro = mysqli_fetch_array($resultado))
	{
		$todosLivros[] = $umLivro;
	}
	return $todosLivros;
}
	
?>
<!DOCTYPE html>
<html>
<head>
<title>Livros</title>
<meta charset="UTF-8">
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<table>
    <caption><h2>Tabela Livros</h2></caption>
  <tr>
    <th>Código</th>
    <th>Título</th>
  </tr>
	<?php foreach ($listaLivros as $livro) { ?>
	<tr>
		<td><?php echo $livro['livcodigo']; ?></td>
		<td><?php echo $livro['livtitulo']; ?></td>
	</tr>
	<?php } ?> <!-- tudo que está entre as chaves de php é repetido para a tabela!-->
</table>

</body>
</html>
